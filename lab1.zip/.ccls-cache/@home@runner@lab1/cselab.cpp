#include <iostream> 
int main() {  
  std::cout << "Welcome to CSE30!";  
  return 0;  
}  

///COMMENT