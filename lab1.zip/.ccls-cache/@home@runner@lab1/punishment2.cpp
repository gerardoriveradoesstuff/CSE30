#include <iostream> 
using namespace std;
int main() { 
  string q = "I wil alway us obj oriented porgramming";
  string y = "I will always use object oriented programming";
  int x;
  int z;
  cout << "Enter the number of lines for punishment" << endl;
  cin >> x;
  if (x < 0) {
    cout << "You have entered an incorrect value for number of lines" << endl;
  }
  cout << "Enter which line to have typo" << endl; 
  cin >> z; 
 
  if (z < 0) {
    cout << "You have entered an incorrect value for typo" << endl;
  }
  for(int i = 0; i < x; i++){
      if(z == i + 1){
        cout << q << endl;
      } else {
        cout << y << endl;
      }
   }
  return 0;  
}  


