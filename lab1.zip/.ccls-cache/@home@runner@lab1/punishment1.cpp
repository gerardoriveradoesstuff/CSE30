#include <iostream> 
using namespace std;
int main() { 
  string y = "I will always use object oriented programming";
  int x;
  cout << "Enter the number of lines for punishment" << endl;
  cin >> x;
  if (x < 0) {
    cout << "You have entered an incorrect value for number of lines" << endl;
  }
  for(int i = 0; i < x; i++){
      cout << y << endl;
   }
  
  return 0;  
}  

