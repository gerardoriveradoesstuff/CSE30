#include <iostream> 
using namespace std;
int main() { 
  string x;
  cout << "Please enter your name" << endl;
  cin >> x;
  cout << "Welcome to CSE30 " << x << "!" << endl;  
  return 0;  
}  

///COMMENT