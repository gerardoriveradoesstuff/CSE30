#include <iostream>

using namespace std;

int main() {
  int array, number, check;
  cout << "Enter the size of the array: ";
  cin >> array;

  // checks if the array size is over 0 and not a negative
  while (array < 0) {
    cout << "ERROR: you entered an incorrect value for the array size!"<< endl;
    return 0;
    if (array > 0){
      cin >> array; 
    }
  }
  //create the array size 
  int arr[array];
  // input for the array
  cout << "Enter the numbers in the array, separated by a space, and press enter: ";
  for (int i = 0; i < array; i++) {
    cin >> arr[i];
  }

  cout << "Enter a number to search for in the array: "; 
  cin >> number;


  
  for (int i = 0; i < array; i++) {
    if (arr[i] == number) {
      cout << "Found value " << number << " at index " << i << ", which took " << (i + 1) << " checks" << endl;
    } 
  }

  if (number == arr[0]) {
    cout << "We ran into the best case scenario" << endl;
  }
  if (number == arr[array-1]){
    cout << "We ran into the worst case scenario!" << endl;
  }


  return 0;
}
