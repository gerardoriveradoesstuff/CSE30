#include <iostream>
using namespace std;

int main() {
  int array;
  cout << "Enter the size of the array: ";
  cin >> array;

  // checks if the array value is correct
  while (array < 0) {
    cout << "ERROR: you entered an incorrect value for the array size!"<< endl;
    return 0;
    if (array > 0){
      cin >> array; 
    }
  }
  
  int arr[array];
  // uses the user input to be put into the array
  cout << "Enter the numbers in the array, separated by a space, and press enter: ";
  for(int i = 0; i < array; i++) {
    cin >> arr[i];
  }

  // swaps an integer from the index into another point in the index
  for(int i = 0; i < array - 1; i++) {
    int selection = i;
    for(int j = i + 1; j < array; j++) {
      if(arr[j] > arr[selection]) {
        selection = j;
      }
    }
    int temp = arr[i];
    arr[i] = arr[selection];
    arr[selection] = temp;
  }

  // prints the order of the array
  cout << "This is the sorted array in descending order: ";
  for(int i = 0; i < array; i++) {
    cout << arr[i] << " ";
  }
  cout << endl;
  cout << "The algorithm selected the maximum for the traverse of the array." << endl;

  return 0;
}
