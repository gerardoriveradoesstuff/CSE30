#include <iostream>

using namespace std;

int main() {
    int size;

    // Ask for the size of the array
    cout << "Enter the size of the array: ";
    cin >> size;

    // Check if the size is not a negative number
    while (size < 0) {
        cout << "The size of the array cannot be negative. Please enter a positive number: ";
        cin >> size;
    }

    int arr[size];

    // Allow the user to input values for the array
    cout << "Enter values for the array: " << endl;
    for (int i = 0; i < size; i++) {
        cin >> arr[i];
    }

    // Output the values of the array
    cout << "The values in the array are: ";
    for (int i = 0; i < size; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;

    // Check if the array is increasing
    bool increasing = true;
    for (int i = 1; i < size; i++) {
        if (arr[i] <= arr[i - 1]) {
            increasing = false;
            break;
        }
    }

    // Output the result
    if (increasing) {
        cout << "The array is increasing." << endl;
    } else {
        cout << "The array is not increasing." << endl;
    }

    return 0;
}
