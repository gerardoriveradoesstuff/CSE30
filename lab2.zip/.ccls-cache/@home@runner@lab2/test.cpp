#include <iostream>
#include <cmath>
  
using namespace std;
  
int main() {
  int n;
  int nC = 0;
  
  // ask user for the dimension of the square array
  cout << "Enter the size of the 2D array: ";
  cin >> n;
  
  // check if number of rows is negative and or too large
  while (n < 0) {
    cout << "ERROR: you entered an incorrect value for the array size! ";
    return 0;
  }
    
  while (n > 10) {
    cout << "ERROR: your array is too large! Enter 1 to 10.  ";
    return 0;
  }
    
    
  int arr[n][n];
  
  // loop to input values of the array one row at a time
  for (int i = 0; i < n; i++) {
    cout << "Enter the values in the array for row " << i + 1 << " separated by a space, and press enter: ";
    for (int j = 0; j < n; j++) {
      cin >> arr[i][j];
      if (arr[i][j] < 0) {
        nC++;
      }
    }
  }
  
  // output the array
  cout << "The square array is: " << endl;
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      cout << arr[i][j] << " ";
    }  
    cout << endl;
  }
  
  // output the number of negative values
  if (nC > 0) {
    cout << "There are " << nC << " negative values in the array." << endl;
  } else {
    cout << "There are no negative values in the array." << endl;
  }
  
  return 0;
}