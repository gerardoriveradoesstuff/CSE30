#include <iostream>
#include <string>

using namespace std;

int main() {
  string str;
  cout << "Enter the string to reverse: ";
  getline(cin, str);
  int length = str.length();
  for (int i = 0; i < length / 2; i++) {
    swap(str[i], str[length - i - 1]);
  }
  cout << "The reverse of the string is: " << str << endl;

  return 0;
}