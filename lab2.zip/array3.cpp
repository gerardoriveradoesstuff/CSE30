#include <iostream>
  
using namespace std;
  
int main() {
  int n, nC = 0;
  cout << "Enter the size of the 2D array: ";
  cin >> n;
  
  while (n < 0) {
    cout << "ERROR: you entered an incorrect value for the array size! " << endl;
    return 0;
  }
    
  while (n > 10) {
    cout << "ERROR: your array is too large! Enter 1 to 10." << endl;
    return 0;
  }
    
  int arr[n][n];
  
  for (int i = 0; i < n; i++) {
    cout << "Enter the values in the array for row " << i + 1 << " separated by a space, and press enter: ";
    for (int j = 0; j < n; j++) {
      cin >> arr[i][j];
      if (arr[i][j] < 0) {
        nC++;
      }
    }
  }
  
  if (nC > 0) {
    cout << "There are " << nC << " negative values!" << endl;
  } else {
    cout << "All values are non-negative!" << endl;
  }
  
  return 0;
}