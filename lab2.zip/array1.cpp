#include <iostream>

using namespace std;

int main() {
  int a;
  cout << "Enter the size of the array: ";
  cin >> a;

  while (a < 0) {
    cout << "ERROR: you entered an incorrect value for the array size!"<< endl;
    return 0;
    if (a > 0){
      cin >> a; 
    }
  }

  int arr[a];
  
  cout << "Enter the numbers in the array, separated by a space, and press enter: ";
  for (int i = 0; i < a; i++) {
    cin >> arr[i];
  }

  bool check = true;
  for (int i = 1; i < a; i++) {
    if (arr[i] <= arr[i - 1]) {
      check = false;
      break;
    }
  }

  if (check) {
    cout << "This IS an increasing array!" << endl;
  } else {
    cout << "This is NOT an increasing array!" << endl;
  }

  for (int i = 0; i < a; i++) {
    cout << arr[i] << " ";
  }
  cout << endl;

  return 0;
}
